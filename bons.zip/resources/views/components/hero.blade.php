<div class="hero">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-lg-5">
                <div class="intro-excerpt">
                    <h1>Bon de restauration <span clsas="d-block">Sante plus</span></h1>
                    <p class="mb-4 text-white">Obtenez une gestion des bons de restauration fluide et claire</p>
                    <p>
                        <a href="{{route('login')}}" class="btn bg-orange-500 px-4 rounded me-2">Se connecter</a>
                        </p>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="hero-text">
                    
                </div>
            </div>
        </div>
    </div>
</div>
