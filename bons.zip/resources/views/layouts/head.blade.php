<link rel="stylesheet" href="{{ asset('build/assets/app-B35vxE7q.css') }}?v=<?echo time();?>">
<link rel="stylesheet" href="{{ asset('build/assets/app-D8Jz5B4_.css') }}?v=<?echo time();?>"> 
<script src="{{ asset('build/assets/app-CGTGA1v5.js') }}?v=<?echo time();?>" ></script>
 <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
 <link rel="stylesheet" href="{{asset('assets/css/home.css')}}">

