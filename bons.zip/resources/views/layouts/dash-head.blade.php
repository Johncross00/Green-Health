<link rel="stylesheet"
href="{{ asset('assets/vendor/vendors/mdi/css/materialdesignicons.min.css') }}?v=<?php echo time(); ?> ">
<link rel="stylesheet" href="{{ asset('assets/vendor/vendors/css/vendor.bundle.base.css') }}?v=<?php echo time(); ?>">

 <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
 <link rel="stylesheet" href="{{asset('assets/css/home.css')}}">


<link rel="stylesheet" href="{{ asset('assets/vendor/vendors/jvectormap/jquery-jvectormap.css') }}?v=<?php echo time(); ?> ">
<link rel="stylesheet"
href="{{ asset('assets/vendor/vendors/flag-icon-css/css/flag-icon.min.css') }}?v=<?php echo time(); ?>">
<link rel="stylesheet"
href="{{ asset('assets/vendor/vendors/owl-carousel-2/owl.carousel.min.css') }}?v=<?php echo time(); ?>">
<link rel="stylesheet"
href="{{ asset('assets/vendor/vendors/owl-carousel-2/owl.theme.default.min.css') }}?v=<?php echo time(); ?>">

<link rel="stylesheet" href="{{ asset('assets/vendor/css/style.css') }}?v=<?php echo time(); ?>">
